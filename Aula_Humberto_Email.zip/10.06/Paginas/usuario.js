function carregarUsuario(){
    var userString=localStorage.getItem("user");
    if(!userString){
        window.location="index.html";
    }else{
        var user=JSON.parse(userString);
        document.getElementById("perfil").innerHTML=
        "<h4>" + user.nome + "<br>" + 
        user.email + "<br>" +
        "Identificador: " + user.id + "<br></h4>";

        document.getElementById("fotoUsuario").innerHTML=
        "<img src=imagens/" +user.foto+ " width='20%'>"
    
    }


}