/*
-- Query: SELECT * FROM aula.tb_aula_artista
LIMIT 0, 1000

-- Date: 2020-06-11 08:37
*/
INSERT INTO `` (`codigo`,`nacionalidade`,`nomeartistico`,`cadastro`) VALUES (1,'Americana','Mick Jaguer','2020-05-01');
INSERT INTO `` (`codigo`,`nacionalidade`,`nomeartistico`,`cadastro`) VALUES (2,'Irlandes','Bono Vox',NULL);
INSERT INTO `` (`codigo`,`nacionalidade`,`nomeartistico`,`cadastro`) VALUES (3,'Brasileira','Belchior',NULL);
INSERT INTO `` (`codigo`,`nacionalidade`,`nomeartistico`,`cadastro`) VALUES (4,'Brasileira','Chimbinha','2020-06-09');
INSERT INTO `` (`codigo`,`nacionalidade`,`nomeartistico`,`cadastro`) VALUES (5,'Americana','Michael Jackson',NULL);
INSERT INTO `` (`codigo`,`nacionalidade`,`nomeartistico`,`cadastro`) VALUES (6,'BRASILEIRA','JOELMA',NULL);
INSERT INTO `` (`codigo`,`nacionalidade`,`nomeartistico`,`cadastro`) VALUES (7,'Mexicana','Chaves e Kiko',NULL);
INSERT INTO `` (`codigo`,`nacionalidade`,`nomeartistico`,`cadastro`) VALUES (8,'Argentina','C. Gardel','2020-05-04');
