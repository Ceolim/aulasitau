/*
-- Query: SELECT * FROM aula.tb_aula_usuario
LIMIT 0, 1000

-- Date: 2020-06-11 08:41
*/
INSERT INTO `` (`id`,`email`,`foto`,`nome`,`senha`) VALUES (1,'bill@gates.com','bill.jfif','Bill Gates','microsoft');
INSERT INTO `` (`id`,`email`,`foto`,`nome`,`senha`) VALUES (2,'steve@jobs.com','steve.jfif','Steve Jobs','apple');
INSERT INTO `` (`id`,`email`,`foto`,`nome`,`senha`) VALUES (3,'erlon@musk.com','erlon.jfif','Erlon Musk','tesla');
