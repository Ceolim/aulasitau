/*
-- Query: SELECT * FROM aula.tb_aula_musicas
LIMIT 0, 1000

-- Date: 2020-06-11 08:41
*/
INSERT INTO `` (`codigo`,`ano`,`titulo`,`artista_codigo`) VALUES (1,1980,'Flats',1);
INSERT INTO `` (`codigo`,`ano`,`titulo`,`artista_codigo`) VALUES (2,1995,'Uncomum',2);
INSERT INTO `` (`codigo`,`ano`,`titulo`,`artista_codigo`) VALUES (3,2010,'Classico Para',3);
INSERT INTO `` (`codigo`,`ano`,`titulo`,`artista_codigo`) VALUES (4,2019,'Descendo ate o chao',4);
INSERT INTO `` (`codigo`,`ano`,`titulo`,`artista_codigo`) VALUES (5,2000,'Fancy',5);
